/*
 * SITEWIDE ONLOAD BEHAVIORS
 */

$(function(){
  
/* Add javascript request type */
  $.ajaxSetup({
    'beforeSend': function(xhr) {xhr.setRequestHeader('Accept', 'text/javascript');}
  });

/* Insert asynchronous content */
  $('.insert').livequery(function(){
    if( $(this).size() ){
      if(!$.fn.insertWithAjax){$.addResource('jquery.insertWithAjax.js');}
//      $(this).insertWithAjax({
//        target : '#record_manager'
//      });
    }
  });

/* Handle ajax posts */
  $('.ajaxed').livequery(function(){
    if( $(this).size() ){
      if(!$.fn.ajaxSubmit){$.addResource('jquery.ajaxSubmit.js');}
      $(this).ajaxSubmit();
    }
  });

});
