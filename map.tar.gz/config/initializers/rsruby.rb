#ENV['R_HOME'] ||= "/Library/Frameworks/R.framework/Resources"
#require 'rsruby'
#$rsruby = RSRuby.instance
#
