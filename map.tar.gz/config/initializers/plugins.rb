gem 'mislav-will_paginate', '~>2.3.6'
require 'will_paginate'
require 'will_paginate/collection'
