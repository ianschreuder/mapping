require 'test_helper'

class CoordsHelperTest < ActionView::TestCase
end
